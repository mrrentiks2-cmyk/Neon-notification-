package app.neonlog;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Local SQLite store for saved notifications. Everything stays on the device. */
final class Store extends SQLiteOpenHelper {
    private static Store instance;
    static final int KEEP = 20000;          // cap rows so the database can't grow without bound

    static synchronized Store get(Context c) {
        if (instance == null) instance = new Store(c.getApplicationContext());
        return instance;
    }

    private Store(Context c) { super(c, "notif.db", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE n (_id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, app TEXT, title TEXT, body TEXT, big TEXT, sub TEXT, t INTEGER, ongoing INTEGER)");
        db.execSQL("CREATE INDEX i_t ON n(t)");
        db.execSQL("CREATE INDEX i_pkg ON n(pkg)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) { }

    long insert(String pkg, String app, String title, String body, String big, String sub, long t, boolean ongoing) {
        ContentValues v = new ContentValues();
        v.put("pkg", pkg); v.put("app", app); v.put("title", title); v.put("body", body);
        v.put("big", big); v.put("sub", sub); v.put("t", t); v.put("ongoing", ongoing ? 1 : 0);
        long id = getWritableDatabase().insert("n", null, v);
        if (id > 0 && id % 500 == 0) trim();
        return id;
    }

    private void trim() {
        try {
            getWritableDatabase().execSQL("DELETE FROM n WHERE _id NOT IN (SELECT _id FROM n ORDER BY t DESC LIMIT " + KEEP + ")");
        } catch (Exception ignored) { }
    }

    private JSONObject row(Cursor c) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", c.getLong(0)); o.put("pkg", c.getString(1)); o.put("app", c.getString(2));
        o.put("title", c.getString(3)); o.put("text", c.getString(4)); o.put("big", c.getString(5));
        o.put("sub", c.getString(6)); o.put("time", c.getLong(7)); o.put("ongoing", c.getInt(8) == 1);
        return o;
    }

    JSONArray list(String q, String pkg, int offset, int limit) {
        JSONArray a = new JSONArray();
        List<String> args = new ArrayList<>();
        StringBuilder w = new StringBuilder("1=1");
        if (!TextUtils.isEmpty(pkg)) { w.append(" AND pkg=?"); args.add(pkg); }
        if (!TextUtils.isEmpty(q)) {
            w.append(" AND (title LIKE ? OR body LIKE ? OR big LIKE ? OR app LIKE ?)");
            String like = "%" + q.replace("%", "\\%").replace("_", "\\_") + "%";
            args.add(like); args.add(like); args.add(like); args.add(like);
        }
        String sql = "SELECT _id,pkg,app,title,body,big,sub,t,ongoing FROM n WHERE " + w +
                " ORDER BY t DESC LIMIT " + limit + " OFFSET " + Math.max(0, offset);
        try (Cursor c = getReadableDatabase().rawQuery(sql, args.toArray(new String[0]))) {
            while (c.moveToNext()) a.put(row(c));
        } catch (Exception ignored) { }
        return a;
    }

    JSONObject detail(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT _id,pkg,app,title,body,big,sub,t,ongoing FROM n WHERE _id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return row(c);
        } catch (Exception ignored) { }
        return null;
    }

    /** pkg -> count, for the apps screen */
    JSONObject counts() {
        JSONObject o = new JSONObject();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT pkg, COUNT(*) FROM n GROUP BY pkg", null)) {
            while (c.moveToNext()) o.put(c.getString(0), c.getInt(1));
        } catch (Exception ignored) { }
        return o;
    }

    /** most recent human label seen for a package */
    String labelOf(String pkg) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT app FROM n WHERE pkg=? AND app IS NOT NULL AND app<>'' ORDER BY t DESC LIMIT 1", new String[]{pkg})) {
            if (c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return null;
    }

    int total() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM n", null)) {
            if (c.moveToFirst()) return c.getInt(0);
        } catch (Exception ignored) { }
        return 0;
    }

    void delete(long id) { getWritableDatabase().delete("n", "_id=?", new String[]{String.valueOf(id)}); }
    void clear() { getWritableDatabase().delete("n", null, null); }
    void clearApp(String pkg) { getWritableDatabase().delete("n", "pkg=?", new String[]{pkg}); }

    /** plain-text dump for export, newest first */
    String exportText() {
        StringBuilder sb = new StringBuilder("Neon Log — сохранённые уведомления\n\n");
        try (Cursor c = getReadableDatabase().rawQuery("SELECT app,pkg,title,body,big,t FROM n ORDER BY t DESC", null)) {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.getDefault());
            while (c.moveToNext()) {
                String big = c.getString(4), body = c.getString(3);
                String text = big != null && big.length() > (body == null ? 0 : body.length()) ? big : body;
                sb.append('[').append(fmt.format(new java.util.Date(c.getLong(5)))).append("] ")
                        .append(c.getString(0)).append(" (").append(c.getString(1)).append(")\n");
                if (!TextUtils.isEmpty(c.getString(2))) sb.append(c.getString(2)).append('\n');
                if (!TextUtils.isEmpty(text)) sb.append(text).append('\n');
                sb.append('\n');
            }
        } catch (Exception ignored) { }
        return sb.toString();
    }
}
