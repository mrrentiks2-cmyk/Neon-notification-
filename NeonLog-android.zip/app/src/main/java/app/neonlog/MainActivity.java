package app.neonlog;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_EXPORT = 21;

    WebView web;
    Store store;
    Cfg cfg;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService bg = Executors.newSingleThreadExecutor();
    final Map<String, byte[]> iconCache = new HashMap<>();
    volatile int insetTop;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = Store.get(this);
        cfg = new Cfg(this);
        LogService.activity = new WeakReference<>(this);

        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(0xFF07070E);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.getDecorView().setOnApplyWindowInsetsListener((v, ins) -> { insetTop = ins.getSystemWindowInsetTop(); return v.onApplyWindowInsets(ins); });

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07070E);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/icon/")) return icon(u.getLastPathSegment());
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (HOST.equals(req.getUrl().getHost())) return false;
                openUrl(req.getUrl().toString());
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "W");
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    /* ======================= app icons ======================= */
    private WebResourceResponse icon(String seg) {
        if (seg == null) return notFound();
        String pkg = seg.endsWith(".png") ? seg.substring(0, seg.length() - 4) : seg;
        try { pkg = Uri.decode(pkg); } catch (Exception ignored) { }
        byte[] png = iconCache.get(pkg);
        if (png == null) {
            png = renderIcon(pkg);
            if (png != null) iconCache.put(pkg, png);
        }
        if (png == null) return notFound();
        WebResourceResponse r = new WebResourceResponse("image/png", null, new ByteArrayInputStream(png));
        Map<String, String> hd = new HashMap<>();
        hd.put("Cache-Control", "max-age=86400");
        r.setResponseHeaders(hd);
        return r;
    }

    private byte[] renderIcon(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            Drawable d = pm.getApplicationIcon(pkg);
            int size = Math.round(44 * getResources().getDisplayMetrics().density);
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(cv);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            bmp.recycle();
            return out.toByteArray();
        } catch (Exception e) { return null; }
    }

    private WebResourceResponse notFound() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
        r.setStatusCodeAndReasonPhrase(404, "Not Found");
        return r;
    }

    /* ======================= events ======================= */
    void emit(JSONObject e) {
        final String js = "window.__wEvent && window.__wEvent(" + JSONObject.quote(e.toString()) + ")";
        ui.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    void emitPosted(JSONObject item) {
        try { emit(new JSONObject().put("type", "posted").put("item", item)); } catch (Exception ignored) { }
    }

    void emitState() {
        try { emit(new JSONObject().put("type", "state")); } catch (Exception ignored) { }
    }

    /* ======================= access ======================= */
    boolean access() {
        try {
            String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            if (flat == null) return false;
            String me = getPackageName();
            for (String part : flat.split(":")) {
                if (part.contains(me + "/")) return true;
            }
            return false;
        } catch (Exception e) { return false; }
    }

    /* ======================= apps list ======================= */
    JSONArray apps() {
        JSONArray a = new JSONArray();
        JSONObject counts = store.counts();
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        try {
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : apps) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                a.put(appRow(pm, pkg, counts.optInt(pkg, 0)));
            }
        } catch (Exception ignored) { }
        // apps that have notified but have no launcher icon
        java.util.Iterator<String> it = counts.keys();
        while (it.hasNext()) {
            String pkg = it.next();
            if (seen.add(pkg) && !pkg.equals(getPackageName())) a.put(appRow(pm, pkg, counts.optInt(pkg, 0)));
        }
        return a;
    }

    private JSONObject appRow(PackageManager pm, String pkg, int count) {
        JSONObject o = new JSONObject();
        String label = pkg;
        try { label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { String l = store.labelOf(pkg); if (l != null) label = l; }
        try { o.put("pkg", pkg).put("label", label).put("count", count).put("on", cfg.isOn(pkg)); } catch (Exception ignored) { }
        return o;
    }

    /* ======================= actions ======================= */
    void openUrl(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { toastUi("Не удалось открыть ссылку"); }
    }

    void openAccess() {
        Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                String comp = getPackageName() + "/" + LogService.class.getName();
                i.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, comp);
            } catch (Exception ignored) { }
        }
        try { startActivity(i); } catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { } }
    }

    void openApp(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) { try { startActivity(i); return; } catch (Exception ignored) { } }
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg))); }
        catch (Exception e) { toastUi("Не удалось открыть приложение"); }
    }

    void startExport() {
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("text/plain").putExtra(Intent.EXTRA_TITLE, "neon-log.txt");
            startActivityForResult(i, REQ_EXPORT);
        } catch (ActivityNotFoundException e) { toastUi("На телефоне нет приложения для сохранения файлов"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_EXPORT && res == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            bg.execute(() -> {
                boolean okr = false;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os != null) { os.write(store.exportText().getBytes("UTF-8")); okr = true; }
                } catch (Exception ignored) { }
                final boolean done = okr;
                toastUi(done ? "История сохранена в файл" : "Не удалось сохранить файл");
            });
        }
    }

    void toastUi(String t) { ui.post(() -> Toast.makeText(this, t, Toast.LENGTH_SHORT).show()); }

    @Override
    protected void onResume() {
        super.onResume();
        emitState();
        try { emit(new JSONObject().put("type", "resume")); } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.__wBack ? window.__wBack() : false", v -> { if (!"true".equals(v)) moveTaskToBack(true); });
    }

    final class Bridge {
        @JavascriptInterface
        public String insets() {
            int top = insetTop;
            if (top == 0) { int id = getResources().getIdentifier("status_bar_height", "dimen", "android"); if (id > 0) top = getResources().getDimensionPixelSize(id); }
            return "{\"top\":" + Math.round(top / getResources().getDisplayMetrics().density) + "}";
        }

        @JavascriptInterface
        public String state() {
            JSONObject o = new JSONObject();
            try {
                o.put("access", access());
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("mode", cfg.mode());
                o.put("ongoing", cfg.ongoing());
                o.put("total", store.total());
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public String list(String json) {
            try {
                JSONObject o = new JSONObject(json);
                return store.list(o.optString("q"), o.optString("pkg"), o.optInt("offset"), Math.min(100, o.optInt("limit", 40))).toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public String apps() { return MainActivity.this.apps().toString(); }
        @JavascriptInterface public String activeApps() { return MainActivity.this.apps().toString(); }

        @JavascriptInterface
        public String detail(String id) {
            try { JSONObject o = store.detail(Long.parseLong(id)); return o == null ? "null" : o.toString(); }
            catch (Exception e) { return "null"; }
        }

        @JavascriptInterface public void setApp(String pkg, boolean on) { cfg.setApp(pkg, on); }
        @JavascriptInterface public void setMode(String m) { cfg.setMode(m); }
        @JavascriptInterface public void setOngoing(boolean v) { cfg.setOngoing(v); }

        @JavascriptInterface public void del(String id) { try { store.delete(Long.parseLong(id)); } catch (Exception ignored) { } }
        @JavascriptInterface public void clear() { store.clear(); }
        @JavascriptInterface public void clearApp(String pkg) { store.clearApp(pkg); }
        @JavascriptInterface public void exportAll() { ui.post(MainActivity.this::startExport); }

        @JavascriptInterface public void openAccess() { ui.post(MainActivity.this::openAccess); }
        @JavascriptInterface public void openApp(String pkg) { ui.post(() -> MainActivity.this.openApp(pkg)); }
        @JavascriptInterface public void openUrl(String u) { ui.post(() -> MainActivity.this.openUrl(u)); }

        @JavascriptInterface
        public void share(String text) {
            ui.post(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Поделиться")); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            ui.post(() -> { ClipboardManager c = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); if (c != null) c.setPrimaryClip(ClipData.newPlainText("Neon Log", text)); });
        }

        @JavascriptInterface public void toast(String t) { toastUi(t); }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try { Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE); if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE)); } catch (Exception ignored) { }
        }

        @JavascriptInterface public String version() { return BuildConfig.VERSION_NAME; }
    }
}
