package app.neonlog;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** What to save: mode, ongoing switch, and the per-app allow/block sets. */
final class Cfg {
    private final SharedPreferences p;

    Cfg(Context c) { p = c.getApplicationContext().getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    String mode() { return p.getString("mode", "all"); }
    void setMode(String m) { p.edit().putString("mode", m).apply(); }

    boolean ongoing() { return p.getBoolean("ongoing", false); }
    void setOngoing(boolean v) { p.edit().putBoolean("ongoing", v).apply(); }

    private Set<String> set(String k) { return new HashSet<>(p.getStringSet(k, new HashSet<>())); }
    private void save(String k, Set<String> v) { p.edit().putStringSet(k, v).apply(); }

    /** whether notifications from pkg are currently saved */
    boolean isOn(String pkg) {
        return "all".equals(mode()) ? !set("excluded").contains(pkg) : set("included").contains(pkg);
    }

    boolean shouldSave(String pkg) { return isOn(pkg); }

    void setApp(String pkg, boolean on) {
        if ("all".equals(mode())) {
            Set<String> ex = set("excluded");
            if (on) ex.remove(pkg); else ex.add(pkg);
            save("excluded", ex);
        } else {
            Set<String> in = set("included");
            if (on) in.add(pkg); else in.remove(pkg);
            save("included", in);
        }
    }
}
