package app.neonlog;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/**
 * Saves notifications the system delivers to this listener into the local database.
 * The listener runs only after the user grants "Notification access" in Android settings,
 * and it never sends anything off the device.
 */
public class LogService extends NotificationListenerService {
    static volatile boolean connected;
    static WeakReference<MainActivity> activity = new WeakReference<>(null);
    private final Map<String, String> labelCache = new HashMap<>();

    @Override public void onListenerConnected() { connected = true; }
    @Override public void onListenerDisconnected() { connected = false; }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try { handle(sbn); } catch (Exception ignored) { }
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;
        int flags = n.flags;
        if ((flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;   // the summary duplicates its children
        boolean ongoing = (flags & Notification.FLAG_ONGOING_EVENT) != 0 || (flags & Notification.FLAG_FOREGROUND_SERVICE) != 0;

        Cfg cfg = new Cfg(this);
        if (ongoing && !cfg.ongoing()) return;
        if (!cfg.shouldSave(pkg)) return;

        Bundle ex = n.extras;
        if (ex == null) return;
        String title = cs(ex.getCharSequence(Notification.EXTRA_TITLE));
        String text = cs(ex.getCharSequence(Notification.EXTRA_TEXT));
        String big = cs(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));
        String sub = cs(ex.getCharSequence(Notification.EXTRA_SUB_TEXT));
        if (TextUtils.isEmpty(sub)) sub = cs(ex.getCharSequence(Notification.EXTRA_INFO_TEXT));
        if (TextUtils.isEmpty(text) && TextUtils.isEmpty(big)) {
            CharSequence[] lines = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null && lines.length > 0) {
                StringBuilder sb = new StringBuilder();
                for (CharSequence l : lines) { if (sb.length() > 0) sb.append('\n'); sb.append(cs(l)); }
                big = sb.toString();
            }
        }
        if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text) && TextUtils.isEmpty(big)) return;
        if (big != null && big.equals(text)) big = "";

        String app = label(pkg);
        long t = sbn.getPostTime();
        if (t <= 0) t = System.currentTimeMillis();
        long id = Store.get(this).insert(pkg, app, title, text, big, sub, t, ongoing);
        if (id <= 0) return;

        MainActivity a = activity.get();
        if (a != null) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", id).put("pkg", pkg).put("app", app).put("title", title)
                        .put("text", text).put("big", big).put("sub", sub).put("time", t).put("ongoing", ongoing);
                a.emitPosted(o);
            } catch (Exception ignored) { }
        }
    }

    private String label(String pkg) {
        String c = labelCache.get(pkg);
        if (c != null) return c;
        String r = pkg;
        try {
            PackageManager pm = getPackageManager();
            r = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception ignored) { }
        labelCache.put(pkg, r);
        return r;
    }

    private static String cs(CharSequence c) { return c == null ? "" : c.toString().trim(); }
}
